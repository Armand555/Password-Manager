# Security Policy

## Supported Versions

Following versions of this project are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 11.00   | :white_check_mark: |
| < 11.00 | :x:                |

## Reporting a Vulnerability

If you find a security vulnerability, report to *i [at] jeffery.cc*

I will fix security bugs ASAP once verified.
